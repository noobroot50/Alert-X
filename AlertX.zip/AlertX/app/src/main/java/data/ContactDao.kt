package com.example.alert_x.data.dao

import androidx.room.*
import com.example.alert_x.data.entity.EmergencyContact

@Dao
interface ContactDao {

    @Query("SELECT * FROM contacts")
    fun getAllContacts(): List<EmergencyContact>

    @Insert
    fun insertContact(contact: EmergencyContact)

    @Delete
    fun deleteContact(contact: EmergencyContact)
}
