package com.example.alert_x

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

data class Contact(
    val name: String,
    val phone: String
)

class ContactsAdapter(
    private val contacts: List<Contact>,
    private val onCall: (String) -> Unit,
    private val onMessage: (String) -> Unit
) : RecyclerView.Adapter<ContactsAdapter.ContactViewHolder>() {

    class ContactViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val txtName: TextView = itemView.findViewById(R.id.txtName)
        val txtPhone: TextView = itemView.findViewById(R.id.txtPhone)
        val btnCall: ImageView = itemView.findViewById(R.id.btnCall)
        val btnMessage: ImageView = itemView.findViewById(R.id.btnMessage)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContactViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_contact, parent, false)
        return ContactViewHolder(view)
    }

    override fun getItemCount() = contacts.size

    override fun onBindViewHolder(holder: ContactViewHolder, position: Int) {
        val contact = contacts[position]
        holder.txtName.text = contact.name
        holder.txtPhone.text = contact.phone

        holder.btnCall.setOnClickListener { onCall(contact.phone) }
        holder.btnMessage.setOnClickListener { onMessage(contact.phone) }
    }
}
