package com.example.alert_x

import android.os.Bundle
import com.example.alert_x.R
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNavigationView)
        bottomNav.setOnItemSelectedListener { item ->
            when(item.itemId) {
                R.id.home -> { loadFragment(HomeFragment()); true }
                R.id.contacts -> { loadFragment(ContactsFragment()); true }
                R.id.settings -> { loadFragment(SettingsFragment()); true }
                else -> false
            }
        }

        bottomNav.selectedItemId = R.id.home
    }

    private fun loadFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commit()
    }
}
