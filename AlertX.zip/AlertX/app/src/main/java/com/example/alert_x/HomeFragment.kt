package com.example.alert_x

import android.Manifest
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.telephony.SmsManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.material.card.MaterialCardView

class HomeFragment : Fragment() {

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private var lastNumber: String? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        val view = inflater.inflate(R.layout.fragment_home, container, false)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(requireActivity())

        val btnSOS = view.findViewById<MaterialCardView>(R.id.btnSOS)
        val btnPolice = view.findViewById<MaterialCardView>(R.id.btnPolice)
        val btnAmbulance = view.findViewById<MaterialCardView>(R.id.btnAmbulance)
        val btnFire = view.findViewById<MaterialCardView>(R.id.btnFire)
        val btnLocation = view.findViewById<MaterialCardView>(R.id.btnLocation)

        btnSOS.setOnClickListener { sendEmergency("112") }
        btnPolice.setOnClickListener { sendEmergency("100") }
        btnAmbulance.setOnClickListener { sendEmergency("102") }
        btnFire.setOnClickListener { sendEmergency("101") }
        btnLocation.setOnClickListener { shareLocationOnly() }

        return view
    }

    // ✅ Permission result handler
    private val requestPermissionsLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->

            val smsGranted = permissions[Manifest.permission.SEND_SMS] == true
            val locGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true

            if (smsGranted && locGranted) {
                lastNumber?.let { sendSMS(it) }
            } else {
                Toast.makeText(requireContext(), "Permission required to send SOS", Toast.LENGTH_SHORT).show()
            }
        }

    // ✅ Only SMS SOS
    private fun sendEmergency(number: String) {

        lastNumber = number

        if (
            ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.SEND_SMS)
            != PackageManager.PERMISSION_GRANTED ||
            ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissionsLauncher.launch(
                arrayOf(
                    Manifest.permission.SEND_SMS,
                    Manifest.permission.ACCESS_FINE_LOCATION
                )
            )
            return
        }

        sendSMS(number)
    }

    // ✅ Send SMS with location
    private fun sendSMS(number: String) {

        fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->

            val message = if (location != null) {
                "🚨 EMERGENCY SOS 🚨\nI need help!\nLocation:\nhttps://maps.google.com/?q=${location.latitude},${location.longitude}"
            } else {
                "🚨 EMERGENCY SOS 🚨\nI need help! Location not available."
            }

            try {
                val smsManager = SmsManager.getDefault()
                smsManager.sendTextMessage(number, null, message, null, null)
                Toast.makeText(requireContext(), "SOS message sent", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(requireContext(), "Failed to send SMS", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ✅ Only open map for user
    private fun shareLocationOnly() {

        fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->

            if (location == null) {
                Toast.makeText(requireContext(), "Location not available", Toast.LENGTH_SHORT).show()
                return@addOnSuccessListener
            }

            val uri =
                android.net.Uri.parse("https://maps.google.com/?q=${location.latitude},${location.longitude}")

            val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, uri)
            startActivity(intent)
        }
    }
}
