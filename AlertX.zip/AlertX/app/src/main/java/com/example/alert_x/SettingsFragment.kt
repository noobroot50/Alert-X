package com.example.alert_x

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.app.ActivityCompat
import com.google.android.material.card.MaterialCardView

class SettingsFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_settings, container, false)

        val cardManageContacts = view.findViewById<MaterialCardView>(R.id.cardManageContacts)
        val cardPermissions = view.findViewById<MaterialCardView>(R.id.cardPermissions)
        val cardAbout = view.findViewById<MaterialCardView>(R.id.cardAbout)
        val cardFeedback = view.findViewById<MaterialCardView>(R.id.cardFeedback)

        // Open ContactsFragment
        cardManageContacts.setOnClickListener {
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, ContactsFragment())
                .addToBackStack(null)
                .commit()
        }

        // Open App Permissions
        cardPermissions.setOnClickListener {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            intent.data = Uri.parse("package:" + requireActivity().packageName)
            startActivity(intent)
        }

        // App Info
        cardAbout.setOnClickListener {
            Toast.makeText(requireContext(), "AlertX v1.0\nInspired by 112 India", Toast.LENGTH_LONG).show()
        }

        // Feedback Mail
        cardFeedback.setOnClickListener {
            val intent = Intent(Intent.ACTION_SENDTO)
            intent.data = Uri.parse("mailto:")
            intent.putExtra(Intent.EXTRA_EMAIL, arrayOf("support@alertx.com"))
            intent.putExtra(Intent.EXTRA_SUBJECT, "Feedback for AlertX App")
            startActivity(intent)
        }

        return view
    }
}
